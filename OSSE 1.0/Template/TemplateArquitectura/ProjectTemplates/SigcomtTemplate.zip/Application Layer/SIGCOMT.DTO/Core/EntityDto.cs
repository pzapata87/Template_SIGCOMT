﻿namespace $safeprojectname$.Core
{
    public class EntityDto<TId>
    {
        public TId Id { get; set; }
    }
}