﻿namespace $safeprojectname$
{
    public class PermisoFormularioDto
    {
        public bool Mostrar { get; set; }
        public bool Crear { get; set; }
        public bool Modificar { get; set; }
        public bool Eliminar { get; set; }
        public bool Imprimir { get; set; }
        public bool Mover { get; set; }
        public bool Reportar { get; set; }
    }
}