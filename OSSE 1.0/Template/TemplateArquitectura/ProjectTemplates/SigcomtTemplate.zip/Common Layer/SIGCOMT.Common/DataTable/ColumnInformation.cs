﻿using System.Collections.Generic;

namespace $safeprojectname$.DataTable
{
    public class ColumnInformation
    {
        public string Columna { get; set; }
        public string Operador { get; set; }
        public List<ValorHomologacion> Valores { get; set; }
    }
}