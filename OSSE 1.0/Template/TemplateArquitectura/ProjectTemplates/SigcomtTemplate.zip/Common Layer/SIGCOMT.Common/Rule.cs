﻿namespace $safeprojectname$
{
    public class Rule
    {
        public string Field { get; set; }

        public string Data { get; set; }

        public string Op { get; set; }
    }
}