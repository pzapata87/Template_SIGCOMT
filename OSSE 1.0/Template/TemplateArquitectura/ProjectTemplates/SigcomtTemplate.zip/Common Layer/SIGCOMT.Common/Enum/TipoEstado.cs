﻿using System;

namespace $safeprojectname$.Enum
{
    [Serializable]
    public enum TipoEstado
    {
        Inactivo = 0,
        Activo = 1
    }
}