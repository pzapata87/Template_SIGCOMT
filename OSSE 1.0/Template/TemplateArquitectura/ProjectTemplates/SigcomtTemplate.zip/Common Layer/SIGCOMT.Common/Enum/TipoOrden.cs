﻿using System;

namespace $safeprojectname$.Enum
{
    [Serializable]
    public enum TipoOrden
    {
        Asc = 0,
        Desc = 1
    }
}