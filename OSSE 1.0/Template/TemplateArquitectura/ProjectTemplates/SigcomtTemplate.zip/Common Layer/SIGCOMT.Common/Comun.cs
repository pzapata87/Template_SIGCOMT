﻿namespace $safeprojectname$
{
    public class Comun
    {
        public string Nombre { get; set; }
        public string Valor { get; set; }
    }
}