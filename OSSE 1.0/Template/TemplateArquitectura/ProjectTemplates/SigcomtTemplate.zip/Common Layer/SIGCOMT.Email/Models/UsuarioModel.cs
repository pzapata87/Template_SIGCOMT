﻿namespace $safeprojectname$.Models
{
    public class UsuarioModel
    {
        public string Usuario { get; set; }
        public string Password { get; set; }
    }
}