﻿namespace $safeprojectname$.Core.Aspects
{
    public enum TipoAccionControlador
    {
        Get = 1,
        Post = 2,
        Listado = 3
    }
}