﻿using log4net;
using PostSharp.Aspects;

namespace $safeprojectname$.Core.Aspects
{
    public interface IControllerMethod
    {
        void Procesar(MethodInterceptionArgs args, ILog log);
    }
}