﻿namespace $safeprojectname$.Core
{
    public class Entity<TId> : EntityWithTypedId<TId>
    {
    }
}