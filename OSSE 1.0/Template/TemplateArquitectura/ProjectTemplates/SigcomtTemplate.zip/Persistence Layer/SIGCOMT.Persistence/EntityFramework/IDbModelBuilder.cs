﻿using System;

namespace $safeprojectname$.EntityFramework
{
    public interface IDbModelBuilder
    {
        void AddConfiguration(Type entityTypeConfiguration);

        void AddEntity(Type entityType);
    }
}