﻿using SIGCOMT.Domain;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$
{
    public interface IItemTablaRepository : IRepositoryWithTypedId<ItemTabla, int>
    {
    }
}