﻿using System;
using System.Linq;
using System.Linq.Expressions;
using SIGCOMT.Common;

namespace $safeprojectname$.Core
{
    public interface IPaging<T> where T : class
    {
        int Count(Expression<Func<T, bool>> @where);
        IQueryable<T> GetAll(FilterParameters<T> parameters);
    }
}