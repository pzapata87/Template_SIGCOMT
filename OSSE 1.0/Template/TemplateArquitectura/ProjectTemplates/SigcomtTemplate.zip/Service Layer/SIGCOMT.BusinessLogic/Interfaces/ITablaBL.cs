﻿using System;
using System.Linq;
using System.Linq.Expressions;
using $safeprojectname$.Core;
using SIGCOMT.Domain;

namespace $safeprojectname$.Interfaces
{
    public interface ITablaBL : IPaging<Tabla>
    {
        Tabla Get(Expression<Func<Tabla, bool>> where);
        IQueryable<Tabla> FindAll(Expression<Func<Tabla, bool>> where);
        Tabla GetById(long id);
    }
}