﻿using System.Web.Mvc;
using $safeprojectname$.Core;

namespace $safeprojectname$.Controllers
{
    public class ErrorController : BaseController
    {
        public ActionResult Index()
        {
            return View("Error");
        }
    }
}