﻿namespace $safeprojectname$.DataTable
{
    public class OrderColumn
    {
        public int Column { get; set; }
        public string Dir { get; set; }
    }
}