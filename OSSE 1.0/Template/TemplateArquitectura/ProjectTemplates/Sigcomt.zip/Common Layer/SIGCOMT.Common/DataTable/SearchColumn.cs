﻿namespace $safeprojectname$.DataTable
{
    public class SearchColumn
    {
        public string Value { get; set; }
        public string Regex { get; set; }
    }
}