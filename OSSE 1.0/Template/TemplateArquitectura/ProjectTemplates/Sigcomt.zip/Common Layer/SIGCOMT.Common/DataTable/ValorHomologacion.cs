﻿namespace $safeprojectname$.DataTable
{
    public class ValorHomologacion
    {
        public string ValorReal { get; set; }
        public string ValorHomologado { get; set; }
    }
}