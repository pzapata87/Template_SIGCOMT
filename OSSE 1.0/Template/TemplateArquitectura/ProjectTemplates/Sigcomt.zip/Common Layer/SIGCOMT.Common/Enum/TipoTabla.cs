﻿using System;

namespace $safeprojectname$.Enum
{
    [Serializable]
    public enum TipoTabla
    {
        Idioma = 1,
        TipoEstado = 2,
        TipoPermiso = 3
    }
}