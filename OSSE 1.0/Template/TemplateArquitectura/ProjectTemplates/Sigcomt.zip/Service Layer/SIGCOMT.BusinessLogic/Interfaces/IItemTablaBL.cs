﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using $safeprojectname$.Core;
using SIGCOMT.Domain;

namespace $safeprojectname$.Interfaces
{
    public interface IItemTablaBL : IPaging<ItemTabla>
    {
        ItemTabla Get(Expression<Func<ItemTabla, bool>> where);
        IList<ItemTabla> FindAll(Expression<Func<ItemTabla, bool>> where);
        void Add(ItemTabla entity);
        void Update(ItemTabla entity);
        void Update(IList<ItemTabla> entities);
        ItemTabla GetById(long id);
    }
}