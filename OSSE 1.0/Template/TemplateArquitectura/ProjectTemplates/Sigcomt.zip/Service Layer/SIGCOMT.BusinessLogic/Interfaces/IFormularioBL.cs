﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using $safeprojectname$.Core;
using SIGCOMT.Domain;

namespace $safeprojectname$.Interfaces
{
    public interface IFormularioBL : IPaging<Formulario>
    {
        Formulario GetById(int id);
        IList<Formulario> FindAll(Expression<Func<Formulario, bool>> where);
        List<Formulario> Formularios(Usuario usuario);
    }
}