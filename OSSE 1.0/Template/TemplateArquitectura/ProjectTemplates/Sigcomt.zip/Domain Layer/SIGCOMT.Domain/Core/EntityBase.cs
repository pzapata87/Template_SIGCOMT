﻿namespace $safeprojectname$.Core
{
    public class EntityBase
    {
        public int Estado { get; set; }
    }
}