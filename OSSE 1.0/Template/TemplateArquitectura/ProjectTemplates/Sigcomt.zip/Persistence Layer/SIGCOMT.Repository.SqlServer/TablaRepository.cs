﻿using System.Data.Entity;
using SIGCOMT.Domain;
using SIGCOMT.Persistence.Core;

namespace $safeprojectname$
{
    public class TablaRepository : RepositoryWithTypedId<Tabla, int>, ITablaRepository
    {
        public TablaRepository(DbContext instanceDbContext)
            : base(instanceDbContext)
        {
        }
    }
}