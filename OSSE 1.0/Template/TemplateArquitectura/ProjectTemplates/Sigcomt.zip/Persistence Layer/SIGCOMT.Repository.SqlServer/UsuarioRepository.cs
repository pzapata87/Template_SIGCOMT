﻿using System.Data.Entity;
using SIGCOMT.Domain;
using SIGCOMT.Persistence.Core;

namespace $safeprojectname$
{
    public class UsuarioRepository : RepositoryWithTypedId<Usuario, int>, IUsuarioRepository
    {
        public UsuarioRepository(DbContext instanceDbContext)
            : base(instanceDbContext)
        {
        }
    }
}