﻿using System.Data.Entity;
using SIGCOMT.Domain;
using SIGCOMT.Persistence.Core;

namespace $safeprojectname$
{
    public class PermisoRolRepository : RepositoryWithTypedId<PermisoRol, int>, IPermisoRolRepository
    {
        public PermisoRolRepository(DbContext instanceDbContext)
            : base(instanceDbContext)
        {
        }
    }
}