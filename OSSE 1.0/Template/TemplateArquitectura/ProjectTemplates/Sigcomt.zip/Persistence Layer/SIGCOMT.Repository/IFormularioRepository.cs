﻿using SIGCOMT.Domain;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$
{
    public interface IFormularioRepository : IRepositoryWithTypedId<Formulario, int>
    {
        //List<Formulario> Formularios(int idRol);
    }
}