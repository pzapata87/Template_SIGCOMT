﻿using SIGCOMT.Domain;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$
{
    public interface IRolRepository : IRepositoryWithTypedId<Rol, int>
    {
    }
}