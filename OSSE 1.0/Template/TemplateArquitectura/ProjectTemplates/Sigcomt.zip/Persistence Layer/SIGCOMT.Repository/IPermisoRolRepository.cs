﻿using SIGCOMT.Domain;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$
{
    public interface IPermisoRolRepository : IRepositoryWithTypedId<PermisoRol, int>
    {
    }
}