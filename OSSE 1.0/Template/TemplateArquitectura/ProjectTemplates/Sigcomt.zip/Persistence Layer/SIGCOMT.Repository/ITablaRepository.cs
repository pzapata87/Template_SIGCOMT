﻿using SIGCOMT.Domain;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$
{
    public interface ITablaRepository : IRepositoryWithTypedId<Tabla, int>
    {
    }
}