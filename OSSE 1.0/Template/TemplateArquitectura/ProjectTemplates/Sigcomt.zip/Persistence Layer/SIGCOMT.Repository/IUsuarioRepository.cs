﻿using SIGCOMT.Domain;
using $safeprojectname$.RepositoryContracts;

namespace $safeprojectname$
{
    public interface IUsuarioRepository : IRepositoryWithTypedId<Usuario, int>
    {
    }
}