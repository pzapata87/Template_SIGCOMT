﻿using System;

namespace $safeprojectname$.EntityFramework
{
    public interface IDatabaseFactory : IDisposable
    {
        DbContextBase Get();
    }
}