﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public static class GlobalParameters
    {
        public static Dictionary<int, string> Idiomas { get; set; }
    }
}
